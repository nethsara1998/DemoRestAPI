package com.nethsara.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.nethsara.demo.dao.StudentRepo;
import com.nethsara.demo.model.Student;

public class MainController implements WebMvcConfigurer {
	
	@Autowired
	StudentRepo repo;		
	
	
	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/result").setViewName("result");
	}
	
	@GetMapping("home")
	public String showForm(Student student) {
		return "index";
	}

	@PostMapping("send")
	public String checkPersonInfo(@Valid Student student, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "index";
		}
		else {
			repo.save(student);		
			return "redirect:/result";
		}
		
	}

}
