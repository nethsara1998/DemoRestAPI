package com.nethsara.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.nethsara.demo.dao.StudentRepo;
import com.nethsara.demo.model.Student;

@Controller
public class MainController {
	
	@Autowired
	StudentRepo repo;
	
	
	@RequestMapping("home1") // localhost:9000/home1	
	public String controller_1() {
		
		System.out.println("Rest API !"); 
		return "index1";
	}
	
	@RequestMapping("home2") // localhost:9000/home2	
	public String controller_2() {
		
		System.out.println("Spring MVC !"); 
		return "index2";
	}	
		
	
	@RequestMapping("send1") // Rest API 
	@ResponseBody
	public Student controller_3(Student student) {		
		
		repo.save(student);			
		return student;
	}
	
	@RequestMapping("send2") // Spring MVC
	public String controller_4(Student student) {		
			
		ModelAndView mv = new ModelAndView();
		mv.addObject("obj", student);
		mv.setViewName("result");
		
		repo.save(student);
		return "result";
	}
	
	
	@RequestMapping("test") // localhost:9000/test?id=CS/2018/029&name=Nethsara	
	public String controller_5(Student student) { 
		
		System.out.println(student.toString());
		return "home1";
	}
}
