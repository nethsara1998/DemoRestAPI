package com.nethsara.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.nethsara.demo.model.Student;

public interface StudentRepo extends CrudRepository<Student, String> {

}
